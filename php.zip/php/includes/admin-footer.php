<?php
/**
 * Created by PhpStorm.
 * User: correywinke
 * Date: 5/17/17
 * Time: 3:39 PM
 */?>
</div><!-- container end -->
<script>
    <?php echo file_get_contents("../../dist/my-com.js") ?>
</script>
</body>
</html>
